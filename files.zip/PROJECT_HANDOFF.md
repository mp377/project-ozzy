# PROJECT HANDOFF — Purview Automated Sensitivity Labeling

**Purpose of this file:** complete context transfer. If you are an AI assistant reading
this on a new machine, this document contains everything needed to resume work without
re-deriving prior findings. Read it fully before proposing changes — several obvious
ideas have already been built, tested, and ruled out (Section 6).

**Last updated:** August 17, 2026
**Sessions completed:** 8

---

## 1. WHAT THIS PROJECT IS

A prototype that automatically applies Microsoft Purview sensitivity labels to documents
based on their content, instead of relying on users to manually pick a label.

**Why it exists:** Miguel built this as a demonstration for **Tim** at his company
(finance / asset management / infrastructure / trading). The demo has already been shown.
Tim's follow-up ask, which is what recent work addresses, was:

> "Make a script that creates a Word or Microsoft Office document and applies a label
> to it during creation. This is part of a bigger project."

Tim has not specified what the bigger project is. Because of that, recent scripts were
built to be callable by other software — structured exit codes, `--json` output, clean
argument surfaces.

**Original requirement, and why it was not met:** Tim originally wanted the label applied
*before saving*, because "when saving, the script was exploding." That specific form is
not achievable with local labeling — see Section 6. The agreed strategy was to demo the
working save-and-close version, explain the constraint honestly, and present Microsoft
Graph API as the resolution path.

---

## 2. ENVIRONMENT

| Item | Value |
|---|---|
| Tenant | `matrixsanbox.onmicrosoft.com` — note: NO 'd', it is "sanbox" |
| Admin account | `TAnderson@matrixsanbox.onmicrosoft.com` |
| Tenant site ID | `4d3efc82-a906-44d5-8f19-512d01df799f` |
| Subscription | Office 365 E3 trial |
| Purview client | version 3.2.92.0 |
| Machine | Windows 11, Node.js v24, npm 11, Python 3.13 |

### Label GUIDs (this tenant only — will differ elsewhere)

| Label | GUID |
|---|---|
| Public | `994c2e99-9b3f-459d-8e3e-36de4c4f4f91` |
| Limited | `7430563a-23b6-4772-b5b1-9317d899d4b3` |
| Restricted | `7cd5dfcb-9dc7-4f57-985b-cabf186e9678` |
| Highly Restricted | `82c90564-5d3b-485b-933a-93e69a6e60ba` |

Retrieve on a different tenant:
```powershell
Connect-IPPSSession -UserPrincipalName <admin@tenant.onmicrosoft.com>
Get-Label | Select-Object DisplayName, Guid
```

### Paths

| What | Where |
|---|---|
| Scripts | `C:\Users\Miguel\OneDrive\Documents\Claudio\katesantos\` |
| Add-in | `C:\Users\Miguel\OneDrive\Documents\Claudio\Purview-addin\Security Label Picker\` |
| Watch folder | `C:\Users\Miguel\LabelTest\` |
| Personal OneDrive | `C:\Users\Miguel\OneDrive\` |
| Work OneDrive | `C:\Users\Miguel\OneDrive - Matrix Sanbox\` |

**Note:** the two OneDrive roots have caused repeated confusion. Scripts live in the
PERSONAL one. Word's default save location was changed to `C:\Users\Miguel\LabelTest`
so the watcher can see files — OneDrive folders cannot be watched (Section 7).

---

## 3. COMPONENTS — five pieces, all working

### 3.1 `apply_label_batch.py` — the labeling engine
Python. Wraps the Purview PowerShell cmdlets (`Get-FileStatus`, `Set-FileLabel`).
Every other component depends on this one.

- Batches files (default 50), parallel workers (default 4)
- Retries on throttling and transient failures
- `--folder` recursive walk, `--force` overwrite, `--justification` for downgrades
- Skips already-labeled files unless forced
- Extensions: docx, docm, dotx, dotm, xlsx, xlsb, xlsm, xltm, xltx, pptx, pptm,
  potx, potm, ppsx, ppsm, pdf
- Label GUIDs HARD-CODED in a `LABEL_MAP` dict

```powershell
python apply_label_batch.py "C:\path\file.docx" "Limited"
python apply_label_batch.py "C:\path\folder" "Restricted" --folder
python apply_label_batch.py "C:\path\file.docx" "Limited" --force --justification "Reclassified"
```

A predecessor `aplicar_etiqueta.py` (Spanish, no batching) exists but is superseded.

### 3.2 Security Label Picker — the Word add-in
HTML + CSS + JavaScript, scaffolded with `yo office` (Task Pane, JavaScript, Word).
Files in `src/taskpane/`: `taskpane.html`, `taskpane.css`, `taskpane.js`.

- `Office.onReady` starts a `setInterval` re-reading the document every **5 seconds**
- Reads body text via `Word.run` → `context.document.body` → `context.load(body,"text")`
- Lowercases, tests against four keyword arrays, highlights the matching label
- Manual "Scan Document" button as a fallback

**Keyword dictionary** — tiers checked in ascending sensitivity, a single higher-tier
match wins:

- *Highly Restricted:* ssn, social security, passport, salary, compensation, bonus,
  portfolio, aum, assets under management, trade secret, account number, credit card,
  bank account, acquisition, merger, insider, algorithm, risk model, non-public,
  confidential, top secret, classified, private equity, hedge fund
- *Restricted:* hr, human resources, legal, contract, nda, non-disclosure, audit,
  compliance, budget, forecast, board, vendor, performance review, internal only,
  proprietary, employee, payroll, benefits, litigation, settlement
- *Limited:* internal, draft, project, meeting, update, report, presentation, proposal,
  agenda, minutes, memo
- *Public:* default when nothing matches

### 3.3 `label_server.py` — Flask bridge
Office Add-ins run browser-sandboxed and cannot invoke Python directly.

- `POST /apply-label` with `{filePath, label}`; `GET /health`
- `flask-cors` required or the add-in's fetch is blocked
- **`debug` MUST be False.** With debug on, Flask auto-reloads on file change and kills
  the in-flight request — this caused a confusing intermittent failure.
- `timeout` 300s

### 3.4 `local_watcher.ps1` — the file watcher
This is what makes the original demo work.

- `FileSystemWatcher` on `C:\Users\Miguel\LabelTest`, filter `*.docx`
- **Uses `$watcher.WaitForChanged()` in a while loop, NOT `Register-ObjectEvent`.**
  This matters: `Register-ObjectEvent` fired events but the action scriptblock did not
  execute reliably. Polling with `WaitForChanged` works.
- Debounces repeats (5s), skips `~$` and `.tmp`
- Retries up to 15 times waiting for Word to release the lock
- Extracts `word/document.xml` from the docx ZIP, strips tags, classifies
- Calls `apply_label_batch.py`

### 3.5 Document creation scripts — three variants (Tim's ask)

**`create_labeled_document.py`** — v1, one-shot CLI.
Creates docx/xlsx/pptx then labels it. Because the script creates the file, nothing has
it open, so there is no lock conflict. Flags: `--title`, `--content`, `--open`,
`--verify`, `--overwrite`, `--json`.
Exit codes: 0 success, 1 labeling failed, 2 creation failed, 3 bad args.

**`create_labeled_document_v2.py`** — adds a warm PowerShell session + interactive prompts.
Flags: `--session`, `--until-office-closes` (polls `tasklist` for WINWORD/EXCEL/POWERPNT),
plus all v1 flags. Exit code 4 added for session start failure.

**`create_labeled_document_gui.py`** — tkinter desktop app. **Current preferred version.**
- Location **dropdown** built from folders that actually exist (scans home dir, finds all
  OneDrive roots). Plus "Browse for another folder..." This structurally prevents the
  invalid-path bug that v2 had — the user cannot type a bad path.
- Live path preview, colour-coded label swatch, status dot, activity log
- Create button disabled until the session is warm
- Window holds the session open, so it warms once

---

## 4. VERIFIED RESULTS

- Word document created + labeled Highly Restricted, `LabelingMethod: Privileged`
- **Label survives the Word save cycle** — opened, edited, saved, closed, still labeled.
  This was the key durability question and it passed.
- Excel verified via GUI: `Testing101.xlsx` labeled Highly Restricted in 0.9s
- Watcher flow verified: type content → save → close → auto-labeled → reopen shows label
- Bulk folder labeling verified

---

## 5. THE PERFORMANCE FINDING — and the open question

Measured timings for the identical `Set-FileLabel` operation:

| Scenario | Time |
|---|---|
| Cold spawned PowerShell process | **91.79s** |
| Warm session, first call | **2.06s** |
| Warm session, after 10 min idle | **0.81s** |

Also measured: module import 0.025s, `Get-FileStatus` 0.89s. So essentially all of the
92 seconds is **engine bootstrap in a fresh process**, not the labeling call.

v1 pays this cost **three times per run** — two `Get-Command` probes plus the batch call,
each spawning its own PowerShell.

### OPEN QUESTION — resolve this before claiming any performance numbers

The GUI reports "Engine ready in 1.7s" and v2 reported 3.1s. A genuine cold bootstrap
should take ~90s. That means the engine was **already warm** before the script started.

Two possibilities, not yet distinguished:
- **Per-process warming** → the warm session is a genuine ~50x win
- **Machine-wide warming that persists** → any process gets ~1s labeling, and the warm
  session only helps on the very first run after a reboot

**The test:** reboot, then run v1 twice on different filenames without rebooting between.
```powershell
Measure-Command { python create_labeled_document.py "C:\Users\Miguel\LabelTest\Cold1.docx" "Limited" } | Select TotalSeconds
Measure-Command { python create_labeled_document.py "C:\Users\Miguel\LabelTest\Cold2.docx" "Limited" } | Select TotalSeconds
```
Both ~90s → per-process. First ~90s, second fast → machine-wide.

The second result would be the more useful finding for Tim's bigger project: a single
warmup call at system startup would solve it for everything.

---

## 6. THE CENTRAL CONSTRAINT — READ BEFORE PROPOSING FIXES

**A file open in Word cannot be labeled by an external process.**

Word takes an exclusive write lock. The Purview client must open the same file to write
label metadata. Windows refuses the second write:

```
Failed to open file, Permission denied, CorrelationId=..., CorrelationId.Description=FileEngine
```

This is file-system behaviour, not a Purview defect and not a bug in the code. Retry and
timeout do not resolve it. Confirmed on both local and OneDrive paths.

### Five approaches built and ruled out — do not repeat these

**1. Labeling Word's `.asd` AutoRecover files**
Located in `C:\Users\Miguel\AppData\Roaming\Microsoft\Word\`. Adding `.asd` to
`ALLOWED_EXTENSIONS` made the script accept them and report success, but `.asd` is not a
real Office format and the label does not transfer to the saved document. `.asd` was
subsequently REMOVED. Do not re-add it.

**2. Writing label metadata via Office.js `customXmlParts`** — closest anything came
The exact Purview metadata format was extracted from a correctly-labeled file:
```xml
<?xml version="1.0" encoding="utf-8" standalone="yes"?>
<clbl:labelList xmlns:clbl="http://schemas.microsoft.com/office/2020/mipLabelMetadata">
  <clbl:label id="{LABEL-GUID}" enabled="1" method="Privileged"
              siteId="{TENANT-SITE-ID}" contentBits="0" removed="0" />
</clbl:labelList>
```
Purview stores this in **TWO** locations inside the docx ZIP:
- `docMetadata/LabelInfo.xml` ← what Purview reads for recognition
- `customXml/item1.xml` ← where Office.js writes

Office.js `customXmlParts.add()` injected it successfully — verified by unzipping. Word
displayed the label name. **Purview did not recognise it**, because `docMetadata/` was
missing and Office.js has no API to write there.

Note the `method="Privileged"` attribute: it means an authorised process applied the
label. Purview validates against the service. Hand-writing metadata is *claiming* a
label, not applying one. If it worked, the control would be worthless — anyone could
mark a document Public and bypass DLP.

**3. `Office.context.document.settings`**
`settings.set()` + `saveAsync()` returned `succeeded`, and `.get()` read the value back
within the session. But it did not persist into the saved file — `null` on a new document.

**4. Forcing a save from the add-in**
`context.document.save()` before invoking the labeler. Word reacquires the lock
immediately, still permission denied. The forced save was removed from `confirmApply()`.

**5. Intercepting Ctrl+N / "New File"**
No Office API exposes this. An add-in cannot load until a document already exists, which
is too late. The supported alternative is **pre-labeled `.dotx` templates** in the
template gallery — not yet built or tested.

### Other blocked APIs
- `Office.context.document.url` returns `undefined` in sideloaded/dev mode, or the
  add-in's TEMP path. Resolves only when deployed through the M365 admin center.
- `window.confirm()` / `window.prompt()` are **blocked** in Office Add-ins. The
  confirmation UI had to be built as an in-pane HTML section.
- `doc.sensitivityLabel` is not supported in this Office.js version.

---

## 7. STORAGE LOCATION STATUS

| Location | Status | Notes |
|---|---|---|
| Local folders | **VERIFIED** | Watcher works, labels apply. What the demo runs on. |
| Network / SMB | **UNTESTED** | `FileSystemWatcher` is documented to work over SMB but has not been verified. Do not claim it works. |
| OneDrive / SharePoint | **DOES NOT WORK** | The sync engine suppresses file-system events. Confirmed by testing — no events fire at all. |

**Three approaches identified for OneDrive, none built:**
1. **Polling** — scan on an interval instead of waiting for events. Simplest.
2. **Graph webhooks** — OneDrive/SharePoint notify the app on change.
3. **Graph labeling** — apply via cloud API rather than file system. Strongest: solves
   the OneDrive problem AND the open-file write-lock constraint together.

---

## 8. KNOWN LIMITATIONS

1. **Cold labeling takes ~92s.** Warm session reduces it to ~1s, but see the open
   question in Section 5.
2. **Keyword rules produce false positives.** A CNN news article was classified Highly
   Restricted because it contained "securities", "position" and "insider". Rules need
   tuning toward specific phrases (`trading position`) over generic words (`position`).
3. **Development-mode file paths** — `Office.context.document.url` unusable while sideloaded.
4. **Hard-coded configuration** — label GUIDs, tenant site ID, folder paths baked into
   source across multiple files. See Section 9 item 1.
5. **Word only** for the add-in. The labeling engine handles Excel/PowerPoint/PDF, but
   the task pane was scaffolded for Word.
6. **No central logging** — results print to console only.

---

## 9. OPEN WORK — priority order

**1. Pull labels from the API instead of hard-coding GUIDs**
- *Quick:* add `GET /labels` to `label_server.py` shelling out to `Get-Label`, cached.
  ~1 hour, no app registration.
- *Proper:* Graph `GET /me/security/informationProtection/sensitivityLabels` with
  `InformationProtectionPolicy.Read` delegated. Returns only labels published to the
  signed-in user, which is correct semantics for a per-user add-in. Needs an Entra app
  registration + admin consent.

Note: labels have a priority/sensitivity ordering and can have parent/child sublabels
(e.g. `Confidential\Internal`). The current four are flat; a real tenant likely is not.

**2. Resolve the warm-engine question** (Section 5) — cheap, and it determines whether
the warm session architecture is worth keeping.

**3. Microsoft Graph labeling** — the real fix for the central constraint.

**4. Tune keyword rules** against real documents.

**5. Test network/SMB shares** to convert that UNTESTED status.

**6. Pre-labeled `.dotx` templates** — the supported answer to "label at File → New".
Untested: does the label propagate from template to new document?

---

## 10. ENTERPRISE DEPLOYMENT REQUIREMENTS

**Licensing:** M365 E3 minimum for manual labels. E5 (or E5 Compliance add-on) for
Purview auto-labeling of files.

**Tenant permissions:** Compliance Administrator or Information Protection Administrator.
Global Reader is a lower-friction read-only alternative. Labels must be *published* to
the test account or they cannot be applied.

**Endpoint:** Purview client installed; PowerShell execution policy permitting local
scripts; Python and Node.js installed. All three commonly blocked on managed builds.

**Add-in deployment:** sideloading is usually disabled by policy. Either enable it for
the account, or publish via **Integrated Apps** in the M365 admin center (Global Admin
approval). This also fixes the `Office.context.document.url` problem.

**If going the Graph route:** Entra app registration with `Files.ReadWrite.All` and
`InformationProtectionPolicy.Read`, plus admin consent.

**Realistic minimum ask:** a test tenant or scoped pilot group, Purview client on one
machine, sideloading permission. The practical blockers are endpoint lockdown and
sideloading policy, not licensing.

---

## 11. HOW TO RUN EVERYTHING

### Prerequisites
```powershell
pip install python-docx openpyxl python-pptx flask flask-cors
Set-Authentication      # sign in as TAnderson@matrixsanbox.onmicrosoft.com
```

### The watcher demo (three windows)
```powershell
# 1 — add-in dev server, opens Word automatically
cd "C:\Users\Miguel\OneDrive\Documents\Claudio\Purview-addin\Security Label Picker"
npm start

# 2 — the watcher
cd "C:\Users\Miguel\OneDrive\Documents\Claudio\katesantos"
.\local_watcher.ps1

# 3 — authenticate
Set-Authentication
```
Then: Ctrl+N → Show Task Pane → type `internal project meeting` (Limited) →
add ` contract audit` (Restricted) → add ` salary portfolio` (Highly Restricted) →
Ctrl+S into LabelTest → Ctrl+W → watcher labels it → reopen, label visible.

### Document creation
```powershell
python create_labeled_document_gui.py                    # GUI, preferred
python create_labeled_document_v2.py --session           # CLI, warm session
python create_labeled_document.py "C:\path\F.docx" "Limited" --verify   # one-shot
```

### Verify a label
```powershell
Get-FileStatus -Path "C:\Users\Miguel\LabelTest\File.docx"
```
Looking for `IsLabeled : True` and `LabelingMethod : Privileged`.

### Clear the Office cache if the add-in shows stale content
```powershell
Stop-Process -Name "WINWORD" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\*" -Recurse -Force -ErrorAction SilentlyContinue
```

### Common gotchas
- `npm start` intermittently fails with "dev server is not running on port 3000" — Ctrl+C
  and run again.
- Close test files in Word before labeling them, or you get permission denied.
- Word's default save location must point at `C:\Users\Miguel\LabelTest` for the watcher
  to see anything.

---

## 12. DELIVERABLES PRODUCED

| File | What it is |
|---|---|
| `Purview_Security_Labeling.pptx` | 12-slide deck: problem, architecture, code, auto-detection engine, what works, the constraint, storage status, limitations, roadmap, potential, summary. Speaker notes on every slide. |
| `create_labeled_document.py` | v1 CLI creator |
| `create_labeled_document_v2.py` | v2 warm session + prompts |
| `create_labeled_document_gui.py` | GUI creator — preferred |
| `PROJECT_HANDOFF.md` | this file |
| `Purview_SessionN_Backup.docx` | session backups 1–6, superseded by this file |

---

## 13. WORKING NOTES FOR THE NEXT ASSISTANT

- Miguel works best **one step at a time**, confirming before moving on. Do not dump
  multi-step instructions.
- When giving code, **always give the complete file to replace wholesale.** Partial edits
  repeatedly caused syntax errors and orphaned code. He explicitly asked for this to stop.
- He asks "is this clean?" before pasting. Verify the file is complete and self-consistent
  before handing it over.
- He sometimes asks for explanations in **Spanish** — be ready to switch.
- Watch the two OneDrive roots (personal vs "Matrix Sanbox"). Path confusion has cost time.
- **Test what you can before delivering.** A GUI shipped with `font=("Consolas", 8.5)`
  crashed on launch because Tk requires integer font sizes. Stubbing the UI framework to
  validate option types would have caught it.
- Context does not persist between conversations. Do not claim to "save" or "remember"
  anything — that is why this file exists.

---

## 14. TIME-SENSITIVE

**The Office 365 E3 trial auto-converts to a paid annual subscription on
August 21, 2026 — $312 charged automatically.**

Cancel at: admin.microsoft.com → Billing → Your products → Cancel subscription
Seven days' grace after that date for a pro-rated refund.

**As of this writing that is four days away.** If the date has passed by the time you
read this, check whether it was cancelled.
